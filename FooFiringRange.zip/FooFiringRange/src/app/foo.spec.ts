import { Foo } from './foo';

describe('Foo', () => {
  it('should create an instance', () => {
    expect(new Foo()).toBeTruthy();
  });
});
